public class Person {
	
	private String name;
	private int IQ;
	
	public Person(String name, int IQ) {
		this.name = name;
		this.IQ = IQ;
	}
	
	public String getName() {
		return name;
	}
	
	public int getIQ() {
		return IQ;
	}
}


