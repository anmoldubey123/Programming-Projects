import java.util.*;

public class ArrayListProbs {
	
	public ArrayListProbs() {
		
	}
	//3
	public void makeListAndPrint(int num, int limit) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        for(int i = 0; i< num; i++) {
            Random random = new Random();
            int r = random.nextInt(limit);
            list.add(r);
            
        }
        System.out.println(list);
    }
	//4
	public ArrayList<Integer> minToFront(ArrayList<Integer> list){
		int minIndex = 0;
	      for (int i = 0; i < list.size(); i++) {
	         if (list.get(i) < list.get(minIndex)) {
	            minIndex = i;
	         }
	      }
	      list.add(0, list.get(minIndex));
		return list;
	}
	//5
	public ArrayList<Integer> addOne(ArrayList<Integer> list)
    {
        int size = list.size();
        for(int i = 0; i< size; i++) {
            list.set(i, list.get(i)+1);
        }
        return list;
    }
	//6
	public ArrayList<String> removeDupes(ArrayList<String> list) {
		ArrayList<String> tempList = new ArrayList<String>();
		for (String duplicateWord : list) {
		    if (!tempList.contains(duplicateWord)) {
		        tempList.add(duplicateWord);
		    }
		}
		return tempList;
	}
	//7
	public ArrayList<Integer> swapPairs(ArrayList<Integer> list) {
		for(int i = 0; i <= list.size() - 2; i += 2) {
	        Integer num = list.get(i + 1);
	        list.set(i + 1, list.get(i));
	        list.set(i, num);
	    }
		return list;
	}
	//8
	public ArrayList<String> removeLenN(ArrayList<String> list, int n) {
		ArrayList<String> tempList = new ArrayList<String>();
		for(int i = 0; i < list.size(); i++) {
	        if(list.get(i).length() != n)
	            tempList.add(list.get(i));
	    }
	    list.clear();
	    list.addAll(tempList);
		return tempList;
	}	
	//9 
	public void answerToRiddle() {
	System.out.println("The letter \"E\"");
	}
	//10
	public int dumbestPerson(ArrayList<Person> list) {
		int x = 0;
		int min = list.get(0).getIQ();
		for(int i = 0; i < list.size(); i++) {
			int num = list.get(i).getIQ();
			if(num < min) {
				min = num;
				x = i;
			}	
	    }
		return x; 
	}
	//13
	public Book highestPricedbook(ArrayList<Book> list) {
        double max = 0;
		for (int i = 1; i < list.size(); i++) {
	         if (list.get(i).getPrice() > max) {
	              max = list.get(i).getPrice();
	         }
	    }
		return String.toString();
	}
}

