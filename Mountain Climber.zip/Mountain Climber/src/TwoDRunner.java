public class TwoDRunner 
{
	public static void main(String[] args) {
		new TwoDArrays(new int[][] {{1, 2}, {10,11}}).sum();
		new TwoDArrays(new int[][] {{1, 2}, {10, 11}}).isSquare();
		System.out.print(new TwoDArrays(new int[][] {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}}).inSequence());
	}
}
