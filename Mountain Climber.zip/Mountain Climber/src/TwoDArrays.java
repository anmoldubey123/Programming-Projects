public class TwoDArrays {
	
	private int[][] nums;

	TwoDArrays(int[][] nums) {
		this.nums = nums;
	}
	
	public int sum() {
		int sum = 0;
		
	    for (int r=0; r < nums.length; r++)
	    {
	        for (int c=0; c < nums[r].length; c++)
	        {
	            sum = sum + nums [r][c];
	        }
	    }
	    return sum;
	}
	
	public boolean isSquare() {
		if(nums.length == nums[0].length) {
		return true;
		}
		else
		return false;
	}
	
	public boolean inSequence() {

		for (int i = 0; i < nums.length - 1; i++) {
	        if (nums[i][i] > nums[i+1][i+1])
	            return false;
	    }
	    return true;
	}
		
	
}
